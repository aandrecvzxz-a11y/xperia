import 'dotenv/config'; import express from 'express'; import cors from 'cors'; import helmet from 'helmet'; import rateLimit from 'express-rate-limit'; import {z} from 'zod'; import {chat,keyStatus} from './services/openrouter.js'; import {safeGet} from './services/safeFetch.js'; import {notFound,errorHandler} from './middleware/errors.js'; import {execFile} from 'node:child_process'; import {promisify} from 'node:util';
const exec=promisify(execFile),app=express(); app.disable('x-powered-by'); app.use(helmet({crossOriginResourcePolicy:{policy:'cross-origin'}}));app.use(cors({origin:(process.env.CLIENT_URL||'http://localhost:5173').split(','),credentials:false}));app.use(express.json({limit:'64kb'}));app.use('/api',rateLimit({windowMs:60_000,limit:40,standardHeaders:true,legacyHeaders:false}));
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'XPERIA PREMIUM',aiKeysConfigured:keyStatus()}));
app.post('/api/ai/chat',async(req,res,next)=>{try{const schema=z.object({messages:z.array(z.object({role:z.enum(['system','user','assistant']),content:z.string().min(1).max(12000)})).min(1).max(40),model:z.string().max(120).optional()});const body=schema.parse(req.body);const result=await chat(body);res.json(result)}catch(e){if(e instanceof z.ZodError)return res.status(400).json({error:'Format pesan tidak valid.'});next(e)}});

// Proxy only fixed, explicitly configured public API endpoints; never accept an arbitrary target URL.
const externalTools = {
  tiktok: { base: 'https://api-cloud.my.id/downloader/tiktok', params: ['url'] },
  instagram: { base: 'https://api-cloud.my.id/downloader/instagram', params: ['url'] },
  gemini: { base: 'https://api-cloud.my.id/ai/gemini', params: ['message','instruction'] },
  claude: { base: 'https://api-cloud.my.id/ai/claude-haiku', params: ['prompt'] },
  gpt: { base: 'https://api-cloud.my.id/ai/gpt', params: ['text'] },
  anime: { base: 'https://api-cloud.my.id/anime/animeplay', params: ['action','query','Page','slug'] },
  spotify: { base: 'https://api-cloud.my.id/search/spotify', params: ['query','limit'] },
  pinterest: { base: 'https://api-cloud.my.id/search/pinterest', params: ['action','query','url'] },
};
app.get('/api/external/:tool', async (req,res) => {
  const config = externalTools[req.params.tool];
  if (!config) return res.status(404).json({error:'Tool eksternal tidak dikenal.'});
  const params = new URLSearchParams();
  for (const key of config.params) {
    const value = req.query[key];
    if (typeof value === 'string' && value.trim()) params.set(key, value.trim().slice(0, 2000));
  }
  if (req.params.tool === 'tiktok' || req.params.tool === 'instagram') {
    const raw=params.get('url');
    if (!raw) return res.status(400).json({error:'Parameter url wajib diisi.'});
    try { const u=new URL(raw); const ok=req.params.tool==='tiktok'?/(^|\.)tiktok\.com$/i.test(u.hostname):/(^|\.)instagram\.com$|(^|\.)instagr\.am$/i.test(u.hostname); if(!['http:','https:'].includes(u.protocol)||!ok) return res.status(400).json({error:'URL platform tidak valid.'}); } catch { return res.status(400).json({error:'URL tidak valid.'}); }
  }
  if (req.params.tool==='spotify') { const n=Number(params.get('limit')||10); if(!Number.isInteger(n)||n<1||n>20) return res.status(400).json({error:'limit harus 1–20.'}); params.set('limit',String(n)); }
  if (req.params.tool==='anime' && !params.has('action')) params.set('action','search');
  if (req.params.tool==='pinterest' && !params.has('action')) params.set('action','search');
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),18000);
  try {
    const upstream=await fetch(`${config.base}?${params.toString()}`,{signal:controller.signal,headers:{accept:'application/json'}});
    const raw=await upstream.text(); let data;
    try { data=JSON.parse(raw); } catch { return res.status(502).json({error:`API eksternal mengirim respons non-JSON (HTTP ${upstream.status}).`}); }
    if(!upstream.ok) return res.status(502).json({error:data?.message||data?.error||`API eksternal HTTP ${upstream.status}.`});
    res.status(200).json(data);
  } catch(e) { res.status(502).json({error:e.name==='AbortError'?'API eksternal melewati batas waktu.':'API eksternal tidak dapat dijangkau.'}); }
  finally { clearTimeout(timer); }
});

app.post('/api/tools/html',async(req,res,next)=>{try{const {url}=z.object({url:z.string().url().max(2048)}).parse(req.body);const r=await safeGet(url,{maxBytes:1_000_000,timeout:10000,accept:'text/html,application/xhtml+xml;q=0.9'});const type=r.headers.get('content-type')||'unknown';if(!/^text\/html\b|^application\/xhtml\+xml\b/i.test(type))return res.status(415).json({error:`URL tidak mengembalikan HTML (Content-Type: ${type}).`,status:r.status,contentType:type});if(r.status<200||r.status>=300)return res.status(502).json({error:`Situs tujuan mengembalikan HTTP ${r.status}; HTML error tidak ditampilkan sebagai hasil sukses.`,status:r.status,contentType:type});res.json({status:r.status,contentType:type,size:r.body.length,html:r.body.toString('utf8')})}catch(e){if(e instanceof z.ZodError)return res.status(400).json({error:'Masukkan URL HTTP/HTTPS yang valid.'});next(e)}});
app.post('/api/tools/download',async(req,res,next)=>{try{const {url,platform}=z.object({url:z.string().url().max(2048),platform:z.enum(['tiktok','instagram'])}).parse(req.body);const u=new URL(url);const allowed=platform==='tiktok'?/(^|\.)tiktok\.com$|(^|\.)vm\.tiktok\.com$/.test(u.hostname):/(^|\.)instagram\.com$|(^|\.)instagr\.am$/.test(u.hostname);if(!allowed)return res.status(400).json({error:`URL bukan URL ${platform} yang didukung.`});
 // Uses the real yt-dlp extractor when installed on the host; no fake metadata or fabricated download URLs.
 try{const {stdout}=await exec('yt-dlp',['--dump-single-json','--no-warnings','--no-playlist','--socket-timeout','12',url],{timeout:20000,maxBuffer:2*1024*1024});const d=JSON.parse(stdout);const formats=(d.formats||[]).filter(f=>f.url&&f.vcodec&&f.vcodec!=='none').slice(-8).map(f=>({url:f.url,format:f.ext||'video',quality:f.format_note||f.height?`${f.format_note||''} ${f.height?f.height+'p':''}`.trim():'Available'}));res.json({title:d.title||'Media',thumbnail:d.thumbnail||null,duration:d.duration||null,platform,formats:formats.length?formats:[{url:d.url,format:d.ext||'video',quality:'Best available'}].filter(x=>x.url),note:'Ketersediaan bergantung pada extractor dan akses publik konten.'})}catch(e){console.error('[downloader]',e.code||e.message);res.status(503).json({error:'Extractor yt-dlp tidak tersedia atau konten tidak dapat diakses. Pasang yt-dlp di server dan pastikan konten bersifat publik.'})}
 }catch(e){if(e instanceof z.ZodError)return res.status(400).json({error:'URL atau platform tidak valid.'});next(e)}});
app.post('/api/tools/nik',(req,res)=>{try{const {nik}=z.object({nik:z.string().max(64)}).parse(req.body);const n=nik.replace(/\s/g,'');if(!/^\d{16}$/.test(n))return res.status(200).json({valid:false,status:'Format tidak valid',message:'NIK harus terdiri dari tepat 16 digit angka.'});const province=n.slice(0,2),city=n.slice(2,4),district=n.slice(4,6),encodedDay=Number(n.slice(6,8)),month=Number(n.slice(8,10)),year=n.slice(10,12),female=encodedDay>=41&&encodedDay<=71,day=female?encodedDay-40:encodedDay;const dateValid=(encodedDay>=1&&encodedDay<=31||encodedDay>=41&&encodedDay<=71)&&[1900+Number(year),2000+Number(year)].some(y=>month>=1&&month<=12&&day>=1&&day<=new Date(y,month,0).getDate());const provinces={'11':'Aceh','12':'Sumatera Utara','13':'Sumatera Barat','14':'Riau','15':'Jambi','16':'Sumatera Selatan','17':'Bengkulu','18':'Lampung','19':'Kepulauan Bangka Belitung','21':'Kepulauan Riau','31':'DKI Jakarta','32':'Jawa Barat','33':'Jawa Tengah','34':'DI Yogyakarta','35':'Jawa Timur','36':'Banten','51':'Bali','52':'Nusa Tenggara Barat','53':'Nusa Tenggara Timur','61':'Kalimantan Barat','62':'Kalimantan Tengah','63':'Kalimantan Selatan','64':'Kalimantan Timur','65':'Kalimantan Utara','71':'Sulawesi Utara','72':'Sulawesi Tengah','73':'Sulawesi Selatan','74':'Sulawesi Tenggara','75':'Gorontalo','76':'Sulawesi Barat','81':'Maluku','82':'Maluku Utara','91':'Papua','92':'Papua Barat'};const cities={'3201':'Kabupaten Bogor','3203':'Kabupaten Cianjur','3275':'Kota Bekasi','3171':'Kota Administrasi Jakarta Pusat','3578':'Kota Surabaya','5171':'Kota Denpasar'};return res.json({valid:dateValid,status:dateValid?'Pola dasar valid':'Tanggal tidak valid',message:dateValid?'Pola tanggal kalender masuk akal; ini bukan verifikasi Dukcapil.':'Tanggal tidak cocok dengan kalender atau pola tanggal NIK.',parts:{provinceCode:province,provinceName:provinces[province]||null,cityCode:province+city,cityName:cities[province+city]||null,districtCode:province+city+district,districtName:null,day:String(day).padStart(2,'0'),month:String(month).padStart(2,'0'),yearSuffix:year,gender:encodedDay>=1&&encodedDay<=31?'Laki-laki':female?'Perempuan':'Tidak diketahui',sequence:n.slice(12,16)},notice:'Pemetaan wilayah lokal pada build ini belum lengkap untuk seluruh Indonesia. Hasil bukan verifikasi resmi kependudukan.'});}catch(e){if(e instanceof z.ZodError)return res.status(400).json({error:'Kirim NIK sebagai teks.'});throw e}});
app.use(notFound);app.use(errorHandler);
// Export the Express app for Vercel serverless functions.
export default app;
// Start a local HTTP server only outside Vercel.
if (!process.env.VERCEL) { const port=Number(process.env.PORT)||3000; app.listen(port,()=>console.log(`XPERIA PREMIUM API listening on ${port}`)); }
