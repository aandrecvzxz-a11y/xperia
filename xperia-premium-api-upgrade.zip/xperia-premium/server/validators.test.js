import test from 'node:test';import assert from 'node:assert/strict';
test('operator prefix normalisation examples',()=>{const normalize=n=>n.replace(/[\s-]/g,'').replace(/^\+?62/,'0');assert.equal(normalize('+628123456789'),'08123456789');assert.equal(normalize('628956123456'),'08956123456')});
test('NIK format requires 16 digits',()=>{assert.match('3174010101010001',/^\d{16}$/);assert.doesNotMatch('1234',/^\d{16}$/)});
